package da222mz_assign1.Exercise_2;

public interface FerryUsageInterface {
	public int getSpace();
	public int getFee();
}
